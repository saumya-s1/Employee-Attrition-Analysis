# Employee Attrition Risk Analysis

Predicting employee attrition using data analytics and visualization.

Tools: Python, Pandas, Matplotlib
